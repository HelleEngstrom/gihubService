To run:

npm install

cd client
npm install

cd server
npm install

npm start
